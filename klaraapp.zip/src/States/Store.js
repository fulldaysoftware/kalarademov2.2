import { configureStore, combineReducers } from '@reduxjs/toolkit';
import sessionSlice from './Session/sessionSlice';
import adminSlice from './Session/adminSlice';
import formSlice from './Session/FormSlice';
import tenantSlice from './Session/tenatId';
// import {  } from ''
// saveState.js

export const saveState = (state) => {
  try {
    const serializedState = JSON.stringify(state);
    localStorage.setItem('state', serializedState);
  } catch (err) {
    console.log("some Error", err);
  }
};

// loadState.js

export const loadState = () => {
  try {
    const serializedState = localStorage.getItem('state');
    if (serializedState === null) {
      return undefined;
    }
    return JSON.parse(serializedState);
  } catch (err) {
    return undefined;
  }
};

const persistedState = loadState();



const rootReducer = combineReducers({
    session: sessionSlice,
    admin: adminSlice,
    form: formSlice,
    tenant: tenantSlice,
})
const store = configureStore({
    reducer: rootReducer,
    preloadedState: persistedState
})

store.subscribe(() => {
  saveState(store.getState()); // Save state to localStorage on every Redux store update
});

export default store