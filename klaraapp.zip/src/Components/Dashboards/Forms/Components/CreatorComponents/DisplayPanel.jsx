import React, { useState } from 'react'
import Grid from '@mui/material/Grid';
import {TextField, Button,Typography,Stack,Chip,FormGroup,Checkbox, FormControlLabel, Select, MenuItem, Paper, InputLabel,FormControl   } from '@mui/material/';
import { Add, LockOutlined, Save } from '@mui/icons-material';
import Avatar from '@mui/material/Avatar';
import Rating from '@mui/material/Rating';
import { useDispatch } from 'react-redux';
import {UploadFile} from "@mui/icons-material"
import store from '../../../../../States/Store';

import { useTheme } from '@emotion/react';
import CreateElement from '../../../Misc/ElementCreator';
import { saveFormMain } from '../../../../../Scripts/Server';
import {useNavigate} from "react-router-dom"

const DsiplayForm=({formState})=>{
    const theme = useTheme()
    const nav = useNavigate()

    const saveForm = async() =>{
    //     {question: question,
    //   type: selectedValue,
    //   required: isChecked,
    //   options: [formOptions], }
         const attributes = store.getState().form.map((item) => {
            return {
                title: item.question,
                inputType: (function() {
                switch (item.type) {
                    case 'Files':
                    return 'FILE';
                    case 'Star Rating':
                    return "INT";
                    default:
                    return "STRING";
                }
                })(),
                required: item.required,
                options: item.options // Assuming options is defined elsewhere
            };
            });

            console.log("TO be Send", { tenantID: store.getState().tenant.tenantID, attributes} );
            const saved  = await saveFormMain({ tenantId: store.getState().tenant.tenantID, attributes})
            nav("/")
            

    }


    // const [fstate, setFstate] = useState(store.getState().form)
    // const updateForms = () => {
    //   setFstate((prev) => {
    //     return [...store.getState().form]
    //   })
    // }
    const paperStyle={padding :20, margin:"0 auto"}
    const avatarStyle={backgroundColor: theme.palette.primary.main}
    const btnstyle={margin:'8px 0'}

    return(
        <form>
        <Paper style={paperStyle} elevation={5}>
        <Grid container gap={3} alignContent="center">
            <Grid xs={12} align={'right'}>
                    <Button variant='contained' size='small' onClick={saveForm}><Save/> Save and Submit</Button>
            </Grid>
            <Grid xs={12}>
                    <h2 color={theme.palette.text.main}>Updated Form</h2>
            </Grid>
            
        { 
            store.getState().form.map((item) => {
            console.log("Execued ", item)
            return CreateElement(item, theme, true)
          })
        }
            
        </Grid>
        </Paper>
        </form>
    )
}

export default DsiplayForm