import * as React from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Unstable_Grid2';
import NoForm from './Components/NoForm';
// import CreateForm from './Components/CreateForm';
import ViewForm from './Components/ViewForm';
// import EditForm from './Components/EditForm';
import store from '../../../States/Store';
import {Button} from '@mui/material'
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getForms } from '../../../Scripts/Server';
import {useDispatch} from 'react-redux'
import { addToFormOnce } from '../../../States/Session/FormSlice';


export default function Form() {
  const nav = useNavigate()
  const dispatch = useDispatch()
  const [startEdit, setStartEdit] = useState(false)
  const [createForm, setCreateForm] = useState(false)

  //     useEffect(() => {
  //   const fetchData = async () => {
  //       const forms = await getForms({tenantID: store.getState().tenant.tenantID})
  //       console.log("result ", forms);
  //       dispatch(addToFormOnce(forms))

  //   // const formState = store.getState().form;
  //   //   setFormData(formState);
  //   };

  //   fetchData(); // Call the function on component mount
  // }, []);


  return (
    <Box sx={{ flexGrow: 1 }}>
      <Grid container spacing={2}>
        <Grid xs={12} alignContent={'left'}>
          {(store.getState().form.length < 1) ? (!createForm && <NoForm createForm = {setCreateForm} />) : <ViewForm setEdit = {setStartEdit}/>}
          
          
          
          {/* {createForm && <CreateForm/>} */}
          {/* <Button onClick={() => {
            nav("/login")
          }}>Login Here</Button> */}
          
          {/* {startEdit && <EditForm offEdit = {setStartEdit} />} */}
          





          {/* <Item> */}
            {/* <h1>You Have No Forms Create New Form</h1> */}
            {}
            {/* <FormActionButton setEditing={setEditing} /> */}
            {/* {editing && <EditorTab/>} */}
          {/* </Item> */}
          {/* <Item>
            {/* <EditorTab/> */}
          {/* </Item>  */}
            {/* <FormActionButton setEditing={setEditing} /> */}
            {/* {editing && <EditorTab/>} */}
          
            {/* <EditorTab/> */}
          
        </Grid>
      </Grid>
    </Box>
  );
}
