import { createSlice } from "@reduxjs/toolkit";


const initialState = [];

const formSlice = createSlice({
    name: "form",
    initialState: initialState,
    reducers: {
        addToFormOnce: (state, action) => {
            console.log("Type state", action.payload);
            // console.log("Old state", state);
            // console.log("New formation", [...state, {...action.payload, ...action.payload.options}]);
            // return [...action.payload, ...action.payload.options];
        },
        addToForm: (state, action) => {
            console.log("Type state", typeof state);
            console.log("Old state", state);
            console.log("New formation", [...state, {...action.payload, ...action.payload.options}]);
            return [...state, {...action.payload, ...action.payload.options}];
        },
        editForm: (state, action) => {
            return state.map(item => {
        if (item.question === action.payload.question) {
          return {
            ...item,
            question: action.payload.question,
            type: action.payload.type,
            required: action.payload.required,
            options: [...action.payload.options] // Create a copy of options array
          };
        }
        return item;
      });
        },
        deleteForm: (state, action) => {
            console.log("from you", action.payload);
            return state.filter(item => item.question !== action.payload.question);
        }
    }
});

export default formSlice.reducer;
export const { addToForm, editForm, deleteForm, addToFormOnce } = formSlice.actions;
