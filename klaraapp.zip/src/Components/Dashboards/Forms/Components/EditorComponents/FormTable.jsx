import { useTheme } from '@emotion/react';
import { Delete, Edit } from '@mui/icons-material';
import {TextField, Button,Typography,Stack,Chip,FormGroup,Checkbox, FormControlLabel, Select, MenuItem, Paper, InputLabel,FormControl   } from '@mui/material/';
import React from 'react';
import { deleteForm } from '../../../../../States/Session/FormSlice';
import { useDispatch } from 'react-redux';
import {useNavigate} from "react-router-dom"

const Table = ({ data, onEdit, onDelete, setDataEdit }) => {
  const nav = useNavigate()
    const theme = useTheme()
    const dispatch = useDispatch()
    const thStyle = {
  backgroundColor: theme.palette.primary.main,
  padding: '12px',
  textAlign: 'left',
  borderBottom: '1px solid #ddd',
  color: "white"
};

const tdStyle = {
  padding: '12px',
  textAlign: 'left',
  borderBottom: '1px solid #ddd'
};

const askConfirmation = (item) => {
    const confirmed = window.confirm('Are you sure you want to delete this item?')
    console.log(item);
    if(confirmed === true) {
        console.log("Working");
        dispatch(deleteForm(item))
        // nav("/editForm")
        window.location.reload();
    }
}


  return (
    <table style={{ borderCollapse: 'collapse', width: '100%' }}>
      <thead>
        <tr>
          <th style={thStyle}>S.No</th>
          <th style={thStyle}>Title</th>
          <th style={thStyle}>Input Type</th>
          <th style={thStyle}>Required</th>
          <th style={thStyle}>Actions</th>
        </tr>
      </thead>
      <tbody>
        {data.map((item, index) => (
          <tr key={index} style={{ borderBottom: '1px solid #ddd' }}>
            <td style={tdStyle}>{index + 1}</td>
            <td style={tdStyle}>{item.question}</td>
            <td style={tdStyle}>{item.type}</td>
            <td style={tdStyle}>{item.required ? 'Yes' : 'No'}</td>
            <td style={tdStyle}>
                <Button><Edit color='warning' onClick={() => setDataEdit((prev) => {return item})} /></Button>
                <Button><Delete color='error' onClick = {() => askConfirmation(item)}/></Button>
              {/* <button onClick={() => onEdit(item)}>Edit</button> */}
              {/* <button style={buttonStyle} onClick={() => onDelete(item)}>Delete</button> */}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default Table;
