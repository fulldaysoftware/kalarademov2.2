export default async function user_login(userData) {
  const config = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'credentials': 'include'
    },
    body: JSON.stringify(userData)
  };

  try {
    const response = await fetch('https://klara-vercel.vercel.app/api/auth/signin', config);
    const responseData = await response.json();

    console.log("response all from logins", responseData);

    if (responseData.success) {
      if (responseData.data.isAdmin === true) {
        // console.log("works ", response.data.tenantId);
        return { isAdmin: true, response: true, data: responseData.data.places, regions: responseData.data.regions, ID:responseData.data.tenantId  };
      }
      return { isAdmin: false, response: true, data: responseData.data.places };
    }

    if (responseData.success === false) {
      return { isAdmin: false, response: false, data: "Wrong Credential" };
    }
  } catch (error) {
    return { isAdmin: false, response: "error", data: "Something is Wrong" };
  }
}

export async function saveFormMain(data) {
  console.log('Response from');
  try {
    const config = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'credentials': 'include'
      },
      body: JSON.stringify(data)
    };

    const response = await fetch('https://klara-vercel.vercel.app/api/reviewAttributes/postReviewAttributes', config);
    const responseData = await response.json();
    console.log('Response:', responseData);
    
    return responseData

  } catch (error) {
    console.error('Error: ', error);
  }
}
export async function signOut() {
  try {
    const config = {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'credentials': 'include'
      }
    };

    const response = await fetch('https://klara-vercel.vercel.app/api/auth/signout', config);
    const responseData = await response.json();
    return responseData
    console.log('Logout Response:', responseData);
  } catch (error) {
    console.error('Error:', error);
  }
}
export async function getForms(data) {
  const temp = {tenantId: data.tenantID}
  try {
    const config = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'credentials': 'include'
      },
      body: JSON.stringify(temp)
    };
    console.log("Got Called", data);

    const response = await fetch('https://klara-vercel.vercel.app/api/reviewAttributes/', config);
    const responseData = await response.json();
    if(responseData.success) {
      return responseData.data.reviewAttributes
    }
    console.log('Logout Response:', responseData);
  } catch (error) {
    console.error('Error:', error);
  }
}



// import axios from "axios"

// export default async function user_login(userData) {
//     const config = {
//     withCredentials: true,
//     method: 'post',
//     // url: 'http://127.0.0.1:3002/api/auth/signin',
//     url: 'https://klara-vercel.vercel.app/api/auth/signin',
//     data: userData // Send userData as the request body
//   };
  
// try {
//     const response = await axios(config);
//     console.log("response all from logins", response);
//     if (response.data.success) {
//       if(response.data.data.isAdmin) {
//         console.log("works ",response);
//         return { isAdmin: true , response: true, data: response.data.data.places, regions: response.data.data.regions  };
//       }
//       return { isAdmin: false ,response: true, data: response.data.data.places };
//     }  
//     if (response.data.success == "false")
//     {
//       return {isAdmin: false , response: false, data: "Wrong Credential" };
//     }
//   } catch (error) {
//     return { isAdmin: false ,response: "error", data: "Something is Wrong" };
//   }
// }

// export async function saveFormMain(data) {
// try {
//     const response = await axios.post('https://klara-vercel.vercel.app/api/reviewAttributes/postReviewAttributes', data);
//     console.log('Response:', response.data);
//   } catch (error) {
//     console.error('Error:', error);
//   }

// }